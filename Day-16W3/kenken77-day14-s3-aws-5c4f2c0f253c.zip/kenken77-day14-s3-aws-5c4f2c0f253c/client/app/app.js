(function(){
    angular.module("UploadApp", ["ngFileUpload"]);
})();