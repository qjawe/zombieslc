(function(){
    angular
        .module("ShoppingCartApp", []);
})();