(function() {
    angular
        .module("EMS", [
            "ngMessages"
            , "ngAnimate"

        ]);
})();
