// TODO: Send and retrieve information from server via Angular $http; modularize via services
// TODO: 1. Define a service that would hold logic related to employee
// TODO: 2. Inject the dependency needed to communicate with the server
// TODO: 3. Create a function that accepts registration information and sends this info to server.
// TODO: 3a Name the function insertEmp
// TODO: 3b Return promise object to calling controller
// TODO: 3c Expose this function.
// TODO: 11 Create a function called getEmpAll that retrieves all employee information from server using HTTP GET.
// TODO: 11 This function returns a promise object.


// TODO: 1.1 Create an IIFE then call your angular module and attach your service to it. Name the service EmpService
(function () {
    // TODO: 2.1 Inject $http. We will use this built-in service to communicate with the server
    // TODO: 1.2 Declare EmpService
    // TODO: 2.2 Accept the injected dependency as a parameter.

        // TODO: 1.3 Assign this object to a variable named service
        // TODO: 3.3 Expose insertEmp
        // TODO: 11.2 Expose retrieveEmp. Arrange in alphabetical order
        // TODO: 3.1 Declare insertEmp; insertEmp must be a private function; insertEmp accepts employee
        // TODO: 3.1  information and returns a promise object to the calling function
            // TODO: 3.2 Return the $http promise object to calling function



        // TODO: 11.1 Declare retrieveEmp; retrieveEmp must be a private function; retrieveEmp retrieves all emp data
        // TODO: 11.1 from server and returns a promise object// retrieveEmp retrieves employee information from the server via HTTP GET.

})();