NodePhotoServer
===============

## Installation instructions

This server assumes you have Node 0.10.x installed somewhere on your computer and in your path. To install, just download the source for this tree or clone it somewhere on your local hard drive and then copy your AngularJS application to the front/ folder within it.


