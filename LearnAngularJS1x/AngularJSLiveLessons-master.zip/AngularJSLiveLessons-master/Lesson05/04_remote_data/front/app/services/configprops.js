(function () {

    photoApp.constant("appConfigurationProps", {
        json_server_host: "localhost",
        json_server_port: 8082
    });

})();
