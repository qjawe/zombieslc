#Easy Form Validation in AngularJS with ngMessages

A tutorial on using Angular's ngMessages API.

Article url: http://www.sitepoint.com/easy-form-validation-angularjs-ngmessages
